<?php

include 'info.php';
$title = ''.$sitename.' - Top Artist';
include 'head.php';

echo '<div class="content" id="content_main">';
echo '<div class="content_title">';
echo '<strong>TOP ARTIST</strong>';
echo '</div>';

$json = file_get_contents('http://ws.audioscrobbler.com/2.0/?method=chart.gettoptags&api_key=7df2ba528dcd0d495e3db6284ee6e1a3&format=json&limit=30&page=1');

$json = json_decode($json, true);

foreach($json['tags']['tag'] as $tags)
{
 $name = $tags['name'];
 $reach = $tags['reach'];
 $tagging = $tags['taggings'];
echo '<div class="content_main">';
 echo '<div class="list_song">';
 echo '<a href="/music/tags/'.$name.'.html" title="Download Music Genre '.$name.' On '.$sitename.'" rel="dofollow">';
 echo '<table class="list_song_table">';
 echo '<tbody>';
 echo '<tr>';
 echo '<td class="list_song_table_left">';
 echo '<img src="http://'.$host.'/files/thumbnail.jpg" alt="'.$name.'" class="thumbnail" />';
 echo '</td>';
 echo '<td class="list_song_table_right">';
 echo '<span class="green-link">';
 echo $name;
 echo '</span>';
 echo '<br />';
 echo $reach;
 echo '<br />';
 echo $tagging;
 echo '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';
 echo '</a>';
 echo '</div>';
 echo '</div>';
}

echo '</div>';
include 'footer.php';

?>