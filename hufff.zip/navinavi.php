<?php

echo '<div style="clear: both;"></div>';

echo '<div class="navi_navi_top" style="margin: 10px 3px;padding: 0px;">';
echo '<a href="http://'.$host.'/topartist" name="Top Artists" title="Top Artists">';
echo '<table style="width: 100%;"><tbody><tr>';
echo '<td valign="top" style="width: 50%;height: 35px;background: #fff;border: 1px solid #1abc9c;text-align: center">';
echo '<span>Top Artists</span>';
echo '</td>';
echo '</a>';
echo '<a href="http://'.$host.'/toptrack" name="Top Tracks" title="Top Tracks">';
echo '<td valign="top" style="width: 50%;height: 35px;background: #fff;border: 1px solid #1abc9c;text-align: center;margin: 0 0 0 3px;">';
echo '<span>Top Tracks</span>';
echo '</td></a></tr><tr>';
echo '<a href="http://'.$host.'/topgenre" name="Top Genre" title="Top Genre">';
echo '<td valign="top" style="width: 50%;height: 35px;background: #fff;border: 1px solid #1abc9c;text-align: center">';
echo '<span>Top Genre</span>';
echo '</td>';
echo '</a>';
echo '<a href="http://'.$host.'/random" name="Top Artists" title="Top Artist">';
echo '<td valign="top" style="width: 50%;height: 35px;background: #fff;border: 1px solid #1abc9c;text-align: center;margin: 0 0 0 3px;">';
echo '<span>Random Music</span>';
echo '</td></a></tr></tbody></table>';
echo '</div>';

?>