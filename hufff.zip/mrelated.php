<?php
$relartist = explode(' ',trim($name));
$relartist = explode(' ',trim($name));
$relartist = str_replace('-','', $relartist);
$jsonr = json_decode(ngegrab('http://api.soundcloud.com/tracks.json?q='.$relartist[0].'&limit=10&offset=0&client_id=30dbd25f772534b4dd327e929644d0d4'));
if(!empty($jsonr[0]->title))
{
echo '<div class="related_music">';
echo '<strong>RELATED MUSIC</strong>';
echo '</div>';
foreach($jsonr as $list)
{
 $idr = $list->id;
 $permalinkr = $list->permalink;
 $namer = $list->title;
 if(!empty($list->artwork_url))
 {
  $thumbr = $list->artwork_url;
 }
 else
 {
  $thumbr = 'http://'.$host.'/files/thumbnail.jpg';
 }
 echo '<div class="content_main">';
 echo '<div class="list_song">';
 echo '<a href="/view/music/'.$idr.'/'.$permalinkr.'.html" title="Download '.$namer.' On '.$sitename.'" rel="dofollow">';
 echo '<table class="list_song_table">';
 echo '<tbody>';
 echo '<tr>';
 echo '<td class="list_song_table_left">';
 echo '<img src="'.$thumbr.'" class="thumbnail" alt="'.$namer.'" />';
 echo '</td>';
 echo '<td class="list_song_table_right">';
 echo '<span class="green-link">';
 echo $namer;
 echo '</span>';
 echo '<br />';
 echo $sitename;
 echo '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';
 echo '</a>';
 echo '</div>';
 echo '</div>';
}
}
?>