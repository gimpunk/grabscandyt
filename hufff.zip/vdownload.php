<?php
include 'vfunc.php';
$id = $_GET['id'];
$gambarnya = 'http://ytimg.googleusercontent.com/vi/'.$id.'/default.jpg';

//Ambil Deskripsi Video

$alamat = file_get_contents('http://www.youtube.com/watch?v='.$id.'&fulldescription=1');
$pecah = explode('<div id="watch-description-text" class="">', $alamat);
$pecah2 = explode('</div>', $pecah[1]);
$ndes = $pecah2[0];

//Udah :D

$yf = samgrab('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=snippet,contentDetails,statistics,topicDetails&id='.$id.'');
$yf = json_decode($yf);
if($yf)
{
foreach ($yf->items as $item)
{
 $name = $item->snippet->title;
 $des = $item->snippet->description;
 $addedon = dateyt($item->snippet->publishedAt);
 $channelid = $item->snippet->channelId;
 $channel = $item->snippet->channelTitle;
 $ctd = $item->contentDetails;
 $duration = sam_time($ctd->duration);
 $hd = $ctd->definition;
 $st= $item->statistics;
 $views = $st->viewCount;
 $likes = $st->likeCount;
 $dislike = $st->dislikeCount;
 $favoriteCount = $st->favoriteCount;
 $commentCount = $st->commentCount;
 $dhfmedia = file_get_contents('http://anunya.esy.es/dhfmedia/getvideo.php?videoid=http://youtube.com/watch?v='.$id.'&type=Download');


 $title = ''.$sitename.' - Download '.$name.' In All Formats';


/********************************************
<a href="/channel/'.$channel.'/'.$channelid.'" title="'.$channel.' All Videos">'.$channel.'</a>
********************************************/

 include 'head.php';
 echo '<div class="content" id="content_main">'; //satu
 echo '<div class="content_view">'; //dua
 echo '<div class="title_video">'; //tiga
 echo '<strong>'.$name.'</strong>';
 echo '<br />';
 echo '<span class="source_video">';
 echo 'Source: http://www.youtube.com/watch?v='.$id.'';
 echo '</span>';
 echo '</div>'; //dua
 include 'ads2.php';
 include 'share.php';
 echo '<div class="content_detail">'; //tiga
 echo '<div class="view_image">'; //empat
 echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/default.jpg" alt="'.$name.'" class="view_thumbnail" />';
 echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/1.jpg" alt="'.$name.'" class="view_thumbnail" />';
 echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/2.jpg" alt="'.$name.'" class="view_thumbnail" />';
 echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/3.jpg" alt="'.$name.'" class="view_thumbnail" />';
 echo '</div>'; //tiga
 echo '<div class="description">'; //empat
 echo '<strong>';
 echo 'VIDEO DESCRIPTION';
 echo '</strong>';
 echo $ndes;
 echo '</div>'; //tiga
 echo '<div class="file_detail">';
 echo '<strong>';
 echo 'VIDEO DETAIL';
 echo '</strong>';
 echo '<p id="eow-detail">';
 echo 'View Count : '.$views.'';
 echo '<br />';
 echo 'Favorite Count : '.$favoriteCount.'';
 echo '<br />';
 echo 'Like Count : '.$likes.'';
 echo '<br />';
 echo 'Dislike Count : '.$dislike.'';
 echo '<br />';
 echo 'Comment Count : '.$commentCount.'';
 echo '<br />';
 echo 'Duration : '.$duration.'';
 echo '<br />';
 echo 'Uploaded On : '.$addedon.'';
 echo '</p>';
 echo '</div>'; //tiga
 echo '</div>'; //dua


/*******************
<div class="biru" align="center">
<i class="fa fa-cloud-download"></i> Watch Video
</div>
<script src="http://www.videoserver.in/developers/htmlsource/'.$_GET['id'].'/youtube.js" /><br/>
</script>
echo'<br/><h2>Embed this video</h2><br/><textarea rows="2" cols="10" style="width: 100%;"><iframe width="600px" height="370px" src="http://'.$host.'/embed/'.$_GET['id'].'.html" scrolling="NO" frameborder="0" style="overflow:hidden; border: 0px;"  webkitallowfullscreen mozallowfullscreen allowfullscreen ></iframe></textarea><br/></div></div>
************/


 echo '<div class="download_files">'; //tiga
 echo '<strong>';
 echo 'DOWNLOAD VIDEO';
 echo '</strong>';
 include 'ads2.php';


// echo '<a href="/ytmp3.php?id='.$id.'&title='.$name.'"><div class="button-link">Download Video As MP3</div></a>';


 echo $dhfmedia;
 include 'ads1.php';
 echo '</div>'; //dua
 echo '</div>'; //satu
 echo '</div>'; //kosong
}
}
include 'vrelated.php';
include 'footer.php';
?>