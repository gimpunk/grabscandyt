<?php

if(!empty($_GET['page']))
{
 $pag = $_GET['page'];
}
else
{
 $pag = '1';
}

include 'info.php';
$title = ''.$sitename.' - Top Artist';
include 'head.php';

echo '<div class="content" id="content_main">';
echo '<div class="content_title">';
echo '<strong>TOP ARTIST</strong>';
echo '</div>';

$json = file_get_contents('http://ws.audioscrobbler.com/2.0/?method=chart.gettopartists&api_key=7df2ba528dcd0d495e3db6284ee6e1a3&format=json&limit=30&page='.$pag.'');

$json = json_decode($json, true);

foreach($json['artists']['artist'] as $artist)
{
 $name = $artist['name'];
 $play = $artist['playcount'];
 $listen = $artist['listeners'];
 $source = $artist['url'];
 $image = $artist['image'][3]['#text'];
 echo '<div class="content_main">';
 echo '<div class="list_song">';
 echo '<a href="/music/'.$name.'.html" title="Download Music '.$name.' On '.$sitename.'" rel="dofollow">';
 echo '<table class="list_song_table">';
 echo '<tbody>';
 echo '<tr>';
 echo '<td class="list_song_table_left">';
 echo '<img src="'.$image.'" alt="'.$artist.' - '.$title.'" class="thumbnail" />';
 echo '</td>';
 echo '<td class="list_song_table_right">';
 echo '<span class="green-link">';
 echo $name;
 echo '</span>';
 echo '<br />';
 echo ''.$play.' Plays';
 echo '<br />';
 echo ''.$listen.' Listeners';
 echo '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';
 echo '</a>';
 echo '</div>';
 echo '</div>';
}
echo '<div class="pagination">';
if($pag > 1)
{
 echo '<a href="/topartist/'.($pag-1).'.html" class="page_item">&#171;Prev</a>';
}
elseif($pag < 11)
{
 echo '<a href="/topartist/'.($pag+1).'.html" class="page_item">Next&#187;</a>';
}

echo '</div>';
echo '</div>';
include 'footer.php';

?>