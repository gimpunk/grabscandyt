<?php
include 'info.php';

$key= 'AIzaSyCHNUXQP5MeHHDqWZM45p5mTdQGvnliCM4';

$juttlog = $_SERVER['HTTP_HOST'];


function ngegrab($url)
{
$ch = curl_init(); curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch,CURLOPT_ENCODING,'gzip');
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$header[] = "Accept-Language: en";
$uaa = $_SERVER['HTTP_USER_AGENT'];
$header[] = "User-Agent: $uaa ";
$header[] = "Pragma: no-cache";
$header[] = "Cache-Control: no-cache";
$header[] = "Accept-Encoding: gzip,deflate";
$header[] = "Content-Encoding: gzip";
$header[] = "Content-Encoding: deflate";
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
$load = curl_exec($ch);
curl_close($ch);
return $load;
}


function samgrab($url)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$uaa = $_SERVER['HTTP_USER_AGENT'];
curl_setopt($ch, CURLOPT_USERAGENT, "User-Agent: $uaa");
return curl_exec($ch);
}


function sam_time($t)
{
$sam = str_replace('PT','',$t);
$sam = str_replace('H','H ',$sam);
$sam = str_replace('M','M ',$sam);
$sam = str_replace('S','S',$sam);
return $sam;
}


function potong($content,$start,$end)
{
if($content && $start && $end)
{
$r = explode($start, $content);
if (isset($r[1]))
{
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}


function format_time($t,$f=':')
{
if($t < 3600)
{
return sprintf("%02d%s%02d", floor($t/60)%60, $f, $t%60);
}
else
{return sprintf("%02d%s%02d%s%02d", floor($t/3600), $f, ($t/60)%60, $f, $t%60);
}
}


function write_to_file($q)
{
$filename = 'sitemap.txt';
$fh = fopen($filename, "a");
if(flock($fh, LOCK_EX))
{
fwrite($fh, $q);
flock($fh, LOCK_UN);
}
fclose($fh);
}


function dateyt($date)
{
$date = substr($date,0,10);
$date = explode('-',$date);
$mn = date('F',mktime(0,0,0,$date[1]));
$dates=''.$date[2].' '.$mn.' '.$date[0].'';
return $dates;
}


function get_size($url)
{
$my_ch = curl_init();
curl_setopt($my_ch, CURLOPT_URL,$url);
curl_setopt($my_ch, CURLOPT_HEADER,         true);
curl_setopt($my_ch, CURLOPT_NOBODY,         true);
curl_setopt($my_ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($my_ch, CURLOPT_TIMEOUT,        10);
$r = curl_exec($my_ch);
foreach(explode("\n", $r) as $header)
{
if(strpos($header, 'Content-Length:') === 0)
{
return trim(substr($header,16));
}
}
return '';
}


function curlGet($URL)
{
$ch = curl_init();
$timeout = 3;
curl_setopt( $ch , CURLOPT_URL , $URL );
curl_setopt( $ch , CURLOPT_RETURNTRANSFER , 1 );
curl_setopt( $ch , CURLOPT_CONNECTTIMEOUT , $timeout );
/* if you want to force to ipv6, uncomment the following line */ 
curl_setopt( $ch , CURLOPT_IPRESOLVE , 'CURLOPT_IPRESOLVE_V6');
$tmp = curl_exec( $ch );
curl_close( $ch );
return $tmp;
}


function cleaned($string)
{
$string = preg_replace('/[^A-Za-z0-9_\s-]/','',$string);
$string = preg_replace('/[\s-]+/',' ',$string);$string = preg_replace('/[\s_]/','-',$string);
$string = strtolower($string);
$string = substr($string,0,45);
return $string;
}

?>