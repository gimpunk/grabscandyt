<?php
include 'info.php';
$title = ''.$sitename.' - Download Billions Music With Free';

include 'head.php';

echo '</div>';
echo '<div class="ngiri"><div class="r"><b>TOP MUSIC LIST</b></div><div class="menu" align="center">';

$jsonData = file_get_contents('https://itunes.apple.com/id/rss/topsongs/limit=30/genre=pop/json');

$jsonData = json_decode($jsonData, true);
foreach ($jsonData['feed']['entry'] as $entry)
{
 $title = $entry['im:name']['label'];
 $image = $entry['im:image'][2]['label'];
 $artist = $entry['im:artist']['label'];
 preg_match("/^(.*?)[^,|&]+/", $artist, $artist);
 $artist = $artist[0];
 $link = $artist.'-'.$title;
 $link = str_replace(' ', '-', $link);
 $link = strtolower($link);
 echo '<a href="/music/'.$artist.' '.$title.'.html" title="Download Music '.$artist.' - '.$title.' On '.$sitename.'" rel="dofollow">';
 echo '<div class="topartist">';
 echo '<img src="'.$image.'" alt="'.$artist.' - '.$title.'" class="thumbnail" />';
 echo '<br/>';
 echo '<p>';
 echo ''.$artist.' - '.$title.'';
 echo '</p>';
 echo $sitename;
 echo '</div>';
 echo '</a>';
}
/*****************************
<a href="/genre/pop.html"><div class="musikgenre">POP</div></a>
<a href="/genre/rock.html"><div class="musikgenre">Rock</div></a>
<a href="/genre/soundtrack.html"><div class="musikgenre">Soundtrack</div></a>
<a href="/genre/dangdut.html"><div class="musikgenre">Dangdut</div></a>
<a href="/genre/remix.html"><div class="musikgenre">Remix</div></a>
<a href="/genre/reggae.html"><div class="musikgenre">Reggae</div></a>
<a href="/genre/hiphop.html"><div class="musikgenre">Hip Hop</div></a>
<a href="/genre/jazz.html"><div class="musikgenre">Jazz</div></a>
<a href="/genre/cover.html"><div class="musikgenre">Cover </div></a>
<a href="/genre/rnb.html"><div class="musikgenre">R & B</div></a>
<a href="/genre/comedy.html"><div class="musikgenre">Comedy</div></a>
<a href="/genre/folk.html"><div class="musikgenre">Folk</div></a>
<a href="/genre/mashup.html"><div class="musikgenre">Mash UP</div></a>
<a href="/genre/instrumental.html"><div class="musikgenre">Instrumental</div></a>
<a href="/genre/religi.html"><div class="musikgenre">Religi</div></a>
******************/
echo '</div>';
include 'footer.php';
?>