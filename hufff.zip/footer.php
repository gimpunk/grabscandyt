<?php
echo '<div class="kaki2">';
echo 'Copyright &copy; 2016 '.$host.'';
echo 'FLMedia - All Rights Reserved';
echo '<br />';
echo '<a href="http://'.$host.'/disclaimer.php" name="Disclaimer" title="Disclaimer">Disclaimer</a>';
echo ' | ';
echo '<a href="http://'.$host.'/contact.php" target="_blank" name="Contact" title="Contact">Contact</a>';
echo ' | ';
echo '<a href="#head">Top^</a>';
echo '</div>';
echo '</body>';
echo '</html>';
?>