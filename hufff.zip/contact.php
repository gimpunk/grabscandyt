<?php
session_start();
include 'info.php';
if(count($_POST)>0)
{
if($_POST["captcha_code"] == $_SESSION["captcha_code"])
{
$name = $_POST['name'];
$email = $_POST['email'];
$msg = $_POST['msg'];
if((!$email) || (strlen($_POST['email']) > 200) || (!preg_match("#^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$#", $email))
)
{
print "Invalid E-Mail Address";
exit;
}
if((!$name) || (strlen($name) > 100) || (preg_match("/[:=@\<\>]/", $name))
)
{
print "Name invalid or too long";
exit;
}
if(preg_match("#cc:#i", $msg, $matches))
{
print "Found Invalid Header Field";
exit;
}
if(!$msg)
{
print 'Write a message';
exit;
}
if(eregi("\r",$email) || eregi("\n",$email))
{
print 'Mail adress is too long or invalid';
exit;
}
$msgs = ''.$email.', '.$msg.'';
$headers .= 'Content-type: text/html\r\n';
$headers = 'From: '.$host.' Contact <$email>';
$recipient = 'adip.perdana@gmail.com';
$subject = 'Contact '.$email.' ('.$host.')';
$msgs = wordwrap($msgs, 1024);
mail($recipient, $subject, $msgs, $headers);
$message = 'Your message received successfully';
}
else
{
$message = "Enter Correct Captcha Code";
}
}
$title = ''.$sitename.' - Contact Us';
include 'head.php';
echo '<div class="content" id="content_main">';
echo '<div class="disclaimer_title">';
echo '<strong>CONTACT US</strong>';
echo '</div>';
echo '<div class="contact">';
include 'ads2.php';
echo $info;
echo '<table><tbody>';
echo '<tr><td>';
echo 'Email';
echo '</td><td>';
echo ': <a href="mailto:'.$mail.'" target="_blank">'.$mail.'</a>';
echo '</td></tr>';
echo '<tr><td>';
echo 'Facebook';
echo '</td><td>';
echo ': <a href="http://fb.com/'.$fbuser.'" target="_blank">Facebook</a>';
echo '</td></tr>';
echo '<tr><td>';
echo 'Twitter';
echo '</td><td>';
echo ': <a href="http://twitter.com/'.$twitter.'" target="_blank">Twitter</a>';
echo '</td></tr>';
echo '</tbody></table>';
echo '<div class="form_contact">';
if(isset($message))
{
echo $message;
}
echo '<form method="post" action="">';
echo 'Your Name :';
echo '<br />';
echo '<input type="text" name="name" size="25" maxlength="15" class="contact_input" placeholder="Your Name" />';
echo '<br />';
echo 'Your Email :';
echo '<br />';
echo '<input type="text" name="email" size="25" maxlength="27" class="contact_input" placeholder="username@domain.com" />';
echo '<br />';
echo 'Your Message :';
echo '<br />';
echo '<textarea name="msg" cols="23" rows="4" class="contact_message" />Great Site Admin !</textarea>';
echo '<br />';
echo '<img src="/files/captcha_code.php" name="cpatcha code" alt="Please Enable Image" />';
echo '<br />';
echo '<input name="captcha_code" type="text" class="contact_captcha">';
echo '<br />';
echo '<input type="submit" name="Submit" value="Submit" class="contact_submit" />';
echo '</form>';
include 'ads2.php';
echo '</div>';
echo '</div>';
echo '</div>';
Include 'footer.php';
?>