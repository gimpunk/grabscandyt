<?php

$keygoogle = str_replace(' ', '+', $name);

$action_post = 'http://www.mywapblog.com/id/post.php';

$array_bg = array('#1abc9c','#2ecc71','#3498db','#9c59c6','#34495e','#f1c40f','#e67e22','#e74c3c');

$colorbg = $array_bg[array_rand($array_bg)];

$body = '
<div style="margin: 0px;padding: 0px;">
<p align="justify">Download Lagu Gratis <a href="'.$url.'" target="_blank" name="Download Lagu Gratis '.$name.'" title="Download Lagu Gratis '.$name.'">'.$name.'</a> Terbaru dan Ngehits ditahun 2016.</p>
<p align="justify">Semua lagu yang ada di blog ini dibagikan secara gratis, agar semua orang dapat mengunduhnya dengan gratis. Tetapi lagu ini bukanlah kualitas yang bagus. Untuk mendapatkan lagu dengan kualitas yang bagus, belilah lagu yang ada di Itunes atau beli CD dari '.$name.' yang ada ditoko terdekat anda.</p>
</div>
<div style="margin: 15px 0px;padding: 0px;text-align: center;">
<img src="'.$thumb.'" alt="Download Lagu Gratis '.$name.'" name="Download Lagu Gratis '.$name.'" width="100px" height="100px" style="margin: 0px;padding: 2px;border: 1px solid #ccc;background: #fff;" />
</div>
<div style="margin: 0px;padding: 0px;text-align: justify;">
<table style="width: 100%;"><tbody>
<tr>
<td style="width: 40%;">Nama</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$name.'</td>
</tr><tr>
<td style="width: 40%;">Dimainkan</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$playcount.'x</td>
</tr><tr>
<td style="width: 40%;">Diunduh</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$downcount.'x</td>
</tr><tr>
<td style="width: 40%;">Menyukai</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$favocount.'</td>
</tr><tr>
<td style="width: 40%;">Komentar</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$comecount.'</td>
</tr><tr>
<td style="width: 40%;">Durasi</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$duration.'</td>
</tr><tr>
<td style="width: 40%;">Ukuran</td><td style="width: 10%;">:</td><td style="width: 50%;">'.$size.'</td>
</tr><tr>
<td style="width: 40%;">Bitrate</td><td style="width: 10%;">:</td><td style="width: 50%;">128kb/s</td>
</tr><tr>
<td style="width: 40%;">Sumber</td><td style="width: 10%;">:</td><td style="width: 50%;"><a href="http://'.$host.'" target="_blank" name="Download Lagu Gratis '.$name.'" title="Download Lagu Gratis '.$name.'">IDMusic</a></td>
</tr>
</tbody></table>
</div>
<br />
<div style="margin: 5px 0px;padding: 0px;text-align: center;">
<span>Download '.$name.'.mp3</span>
<br />
<br />
<a href="'.$url.'" name="Download Button" title="Download Button" class="mime-download" style="background: '.$colorbg.';color: #fff;margin: 6px 5;padding: 8px 10px;text-align: center;border: none;font-weight: bold;display: block;">DOWNLOAD ( '.$size.' )</a>
</div>
<br />
<div class="clear" style="clear: both;">
</div>
<div style="margin: 14px 0px 0px;padding-top: 7px;border-top: 1px solid #ccc;">
<p align="justify">Sebelumnya Saya mengucapkan banyak terima kasih bagi Anda yang telah berkunjung ke <a href="/">Blog Saya</a> untuk mencari dan mengunduh lagu '.$name.'.</p>
<p align="justify">Disini kami menyediakan lagu '.$name.' untuk review saja, apabila Anda menginginkan lagu '.$name.', belilah CD/Kaset/Original dari Albumnya. Anda juga bisa mengaktifkan NSP/RBT/I-RING lagu '.$name.'.</p>
<p align="justify">Jika Anda menginginkan juga lirik dari lagu '.$name.', Anda dapat mencarinya di <a href="http://www.google.co.id/search?q=Lirik+'.$keygoogle.'" target="_blank">Google</a>.</p>
<p align="justify"><u>Untuk Update lagu-lagu terbaru lainnya, silahkan Bookmark alamat Situs =>> <a name="no-link">http://www.flmedia.us.to</a> !</u></p>
</div>
';

$body_article = htmlspecialchars($body);

echo '<div class="post_mwb">';
echo '<strong>POST TO MYWAPBLOG</strong>';
echo '<form method="post" action="'.$action_post.'" class="form_mwb">';
echo '<input type="hidden" name="PHPSESSID" value="">';
echo '<b>Title Article</b>';
echo '<br />';
echo '<input id="post_title" name="title" type="text" value="Download Lagu '.$name.'.mp3 ( '.$size.' )">';
echo '<br />';
echo '<b>Content Article</b>';
echo '<br />';
echo '<textarea id="post_body" name="body" cols="25" rows="2">'.$body_article.'</textarea>';
echo '<br />';
echo '<center><input type="submit" name="preview" value="Posting"></center>';
echo '</form>';
echo '</div>';

?>