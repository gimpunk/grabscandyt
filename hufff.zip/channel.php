<?php
include 'vfunc.php';
if($_GET['channel'])
{
$channel = $_GET['channel'];
} 
$title =''.$channel.' Channel ';
include 'head.php';
if(!empty($_GET['channel']))
{
echo '<div class="biru">'.$channel.' Channel</div>';
}
$qu=$channel;
$qu=str_replace(" ","+", $qu);
$qu=str_replace("-","+", $qu);
$qu=str_replace("_","+", $qu); 
if(strlen($_GET['page']) >1)
{
$yesPage=$_GET['page'];
}
else
{
$yesPage='';
}
$grab = samgrab('https://www.googleapis.com/youtube/v3/search?part=snippet&order=relevance&q='.$qu.'&key='.$key.'&maxResults=10&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage=$json->nextPageToken;
$prevpage=$json->prevPageToken;
if($json)
{
foreach ($json->items as $hasil)
{
$id          = $hasil->id->videoId;
$name        = $hasil->snippet->title;
$description = $hasil->snippet->description;
$channel     = $hasil->snippet->channelTitle;
$chhannelid  = $hasil->snippet->channelId;
$addedon     = dateyt($hasil->snippet->publishedAt);
$hasil       = samgrab('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id.'');
$dt          = json_decode($hasil);
foreach ($dt->items as $dta)
{
$time        = $dta->contentDetails->duration;
$duration    = sam_time($time);
$views       = $dta->statistics->viewCount;
$likes       = $dta->statistics->likeCount;
$dislikes    = $dta->statistics->dislikeCount;
}
echo'<div class="menu"><table class="otable" width="100%"><tbody><tr><td valign="middle" width="75px" align="center"><img src="http://ytimg.googleusercontent.com/vi/'.$id.'/default.jpg" class="thumbnail" alt="Thumbnail"></td><td><i class="icon-external-link"></i> <a href="/youtube-download/'.$id.'?utm_ref=search" title="Download '.$name.' Video Free">'.$name.'</a><br/><i class="icon-time"></i> '.$duration.'<br/><i class="icon-eye-open"></i> '.$views.' Views
<br/><i class="icon-upload-alt"></i> by '.$channel.'
</td></tr></tbody></table></div>';
 }
echo '<div class="nav" align="center">';
if (strlen($prevpage)>1)
{
if (strlen($_GET['channel'])>1)
{
echo '<a href="/channel/'.$_GET['channel'].'&page/'.$prevpage.'" class="page_item">&#171;Prev</a>';
}
}
if (strlen($nextpage)>1)
{
if (strlen($_GET['channel'])>1)
{
echo '<a href="/channel/'.$_GET['channel'].'&page/'.$nextpage.'" class="page_item">Next&#187;</a>';
}
}
echo '</div>';
}
if(!empty($_GET['channel']) AND empty($_GET['page'])){$user_query = ''.$_GET['channel'].'';
write_to_file($user_query);
}
include 'footer.php';
?>