<?php
include 'vfunc.php';

$title = ''.$sitename.' - Download Billions Videos With Free';

include 'head.php';
$search = 'NEW';
 echo '</div>';
echo '<div class="ngiri">';
echo '<div class="r">';
echo '<b>';
echo '<strong>TOP VIDEO LIST</strong>';
echo '</b>';
echo '</div>';
echo '<div class="menu" align="center">';

if(strlen($_GET['page']) >1)
{
 $yesPage = $_GET['page'];
}
else
{
 $yesPage='';
}

/********************************************
https://www.googleapis.com/youtube/v3/videos?key={$this->key}&part=snippet,contentDetails,statistics&chart=mostPopular&maxResults={$this->limit}
*********************************************
https://www.googleapis.com/youtube/v3/search?part=snippet&order=relevance&q='.$search.'&key='.$key.'&maxResults=10&pageToken='.$yesPage.'&type=video
********************************************/




$grab = samgrab('https://www.googleapis.com/youtube/v3/search?part=snippet&order=relevance&q='.$search.'&key='.$key.'&maxResults=10&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage = $json->nextPageToken;
$prevpage = $json->prevPageToken;
if($json)
{
foreach ($json->items as $hasil)
{
 $id = $hasil->id->videoId;
 $name = $hasil->snippet->title;
 $bersih = cleaned($name);
 $description = $hasil->snippet->description;
 $channel = $hasil->snippet->channelTitle;
 $chhannelid = $hasil->snippet->channelId;
 $samdate = dateyt($hasil->snippet->publishedAt);



/*******https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id.'
*********/



 $hasil = samgrab('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id.'');
 $dt = json_decode($hasil);
 foreach ($dt->items as $dta)
 {
  $time = $dta->contentDetails->duration;
  $samtime = sam_time($time);
  $views = $dta->statistics->viewCount;
  $likes = $dta->statistics->likeCount;
  $dislikes = $dta->statistics->dislikeCount;	
 }
 echo '<a href="/view/videos/'.$id.'/'.$bersih.'.html" title="Download '.$name.' On '.$sitename.'">';
 echo '<div class="topartist">';
 echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/default.jpg" class="thumbnail" alt="Thumbnail" />';
 echo '<br/>';
 echo '<p>';
 echo $name;
// echo '<br>'.$bersih.'';
 echo '</p>';
 echo '</div>';
 echo '</a>';
}
echo '<div class="pagination">';
if (strlen($prevpage)>1)
{
 echo '<a href="/videos/page/'.$prevpage.'.html" class="page_item">&#171;Prev</a>';
}
if (strlen($nextpage)>1)
{
 echo '<a href="/videos/page/'.$nextpage.'.html" class="page_item">Next&#187;</a>';
}
}
else
{
echo 'please contact nahar.id22@gmail.com';
}
echo '</div>';
echo '</div>';
include 'footer.php';
?>