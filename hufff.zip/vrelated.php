<?php
echo '<div class="related_video">';
echo '<strong>RELATED VIDEO</strong>';
echo '</div>';
$grab = samgrab('https://www.googleapis.com/youtube/v3/search?key='.$key.'&part=snippet&maxResults=10&relatedToVideoId='.$_GET['id'].'&type=video');
$json = json_decode($grab);
if($json)
{
foreach($json->items as $hasil)
{
$namer = $hasil->snippet->title;
$bersihr = cleaned($namer);
$id = $hasil->id->videoId;
$tgl = $hasil->snippet->publishedAt;
$adip = dateyt($tgl);
$des = $hasil->snippet->description;
$chid = $hasil->snippet->channelId;
$hasil = samgrab('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id.'');
$dt = json_decode($hasil);
foreach ($dt->items as $dta)
{
$timer = $dta->contentDetails->duration;
$ganteng = sam_time($timer);
$views = $dta->statistics->viewCount;
$likes = $dta->statistics->likeCount;	
}
echo '<div class="content_main">';
echo '<div class="list_song">';
echo '<a href="/view/videos/'.$id.'/'.$bersihr.'.html" title="Download '.$name.' On '.$sitename.'">';
echo '<table class="list_song_table">';
echo '<tbody>';
echo '<tr>';
echo '<td class="list_song_table_left">';
echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/default.jpg" class="thumbnail" alt="'.$namer.'" />';
echo '</td>';
echo '<td class="list_song_table_right">';
echo '<span class="green-link">';
echo $namer;
echo '</span>';
echo '<br />';
echo 'Time: '.$ganteng.'';
echo '<br />';
echo 'Upload: '.$adip.'';
echo '</td>';
echo '</tr>';
echo '</tbody>';
echo '</table>';
echo '</a>';
echo '</div>';
echo '</div>';
}
}
?>