<?php

echo '<div class="share-it">';
echo '<span>';
echo 'SHARE THIS PAGE ON';
echo '</span>';
echo '<br />';

echo '<a href="https://www.facebook.com/sharer/sharer.php?u='.$url.'" target="_blank">';
echo '<img src="http://'.$host.'/files/Facebook.png" class="soms" />';
echo '</a>';

echo '<a href="https://twitter.com/intent/tweet?source='.$url.'&text='.$title.': '.$url.'&via=idmusic" target="_blank" title="Tweet">';
echo '<img src="http://'.$host.'/files/Twitter.png" class="soms" />';
echo '</a>';

echo '<a href="https://plus.google.com/share?url='.$url.'" target="_blank" title="Share on Google+">';
echo '<img src="http://'.$host.'/files/Google+.png" class="soms" />';
echo '</a>';
/*
echo '<a href="http://www.tumblr.com/share?v=3&u='.$url.'&t='.$title.'&s=" target="_blank" title="Post to Tumblr">';
echo '<img src="files/Tumblr.png" class="soms">';
echo '</a>';

echo '<a href="http://pinterest.com/pin/create/button/?url='.$url.'&media='.$gambar.'&description='.$title.'" target="_blank" title="Pin it">';
echo '<img src="files/Pinterest.png" class="soms">';
echo '</a>';

echo '<a href="https://getpocket.com/save?url='.$url.'&title='.$title.'" target="_blank" title="Add to Pocket">';
echo '<img src="files/Pocket.png" class="soms">';
echo '</a>';

echo '<a href="http://www.reddit.com/submit?url='.$url.'&title='.$title.'" target="_blank" title="Submit to Reddit">';
echo '<img src="files/Reddit.png" class="soms">';
echo '</a>';
*/
echo '<a href="http://www.linkedin.com/shareArticle?mini=true&url='.$url.'&title='.$title.'&summary='.$title.'&source='.$url.'" target="_blank" title="Share on LinkedIn">';
echo '<img src="http://'.$host.'/files/LinkedIn.png" class="soms" />';
echo '</a>';
/*
echo '<a href="http://wordpress.com/press-this.php?u='.$url.'&t='.$title.'&s='.$title.'&i='.$gambar.'" target="_blank" title="Publish on WordPress">';
echo '<img src="files/Wordpress.png" class="soms">';
echo '</a>';

echo '<a href="https://pinboard.in/popup_login/?url='.$url.'&title='.$title.'&description='.$title.'" target="_blank" title="Save to Pinboard">';
echo '<img src="files/Pinboard.png" class="soms">';
echo '</a>';

echo '<a href="mailto:?subject='.$title.'&body='.$title.': '.$url.'" target="_blank" title="Email">';
echo '<img src="files/Email.png" class="soms">';
echo '</a>';
*/

echo '</div>';
?>