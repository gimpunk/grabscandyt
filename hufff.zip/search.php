<?php


$q = $_GET['q'];
$type = $_GET['type'];

if(!empty($q))
{
if($type == "music" || $type == "videos" || $type == "image")
{
if($type == "music")
{
header('location: /music/'.$q.'.html');
}
if($type == "videos")
{
header('location: /videos/'.$q.'.html');
}
if($type == "image")
{
header('location: /gambar/'.hapus($q).'.html');
}
}
else
{
header('location: /');
}
}
else
{
header('location: /');
}
?>