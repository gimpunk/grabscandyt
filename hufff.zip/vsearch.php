<?php
include 'vfunc.php';
if($_GET['q'])
{
 $q = $_GET['q'];
}
else
{
 $q='NEW';
} 

$title =''.$sitename.' - Download Billions Videos With Free';

include 'head.php';

$qu = $q;
$qu = str_replace(" ","+", $qu);
$qu = str_replace("-","+", $qu);
$qu = str_replace("_","+", $qu);

echo '<div class="content" id="content_main">';
echo '<div class="content_title">';
echo '<strong>SEARCH RESULT</strong>';
echo '</div>';

if(strlen($_GET['page']) >1)
{
 $yesPage=$_GET['page'];
}
else
{
 $yesPage='';
}
$grab = samgrab('https://www.googleapis.com/youtube/v3/search?part=snippet&order=relevance&q='.$qu.'&key='.$key.'&maxResults=10&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage = $json->nextPageToken;
$prevpage = $json->prevPageToken;
if($json)
{
foreach ($json->items as $hasil)
{
 $id = $hasil->id->videoId;
 $name = $hasil->snippet->title;
 $bersih = cleaned($name);
 $description = $hasil->snippet->description;
 $channel = $hasil->snippet->channelTitle;
 $chhannelid = $hasil->snippet->channelId;
 $samdate = dateyt($hasil->snippet->publishedAt);
 
$hasil = samgrab('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id.'');
 
$dt = json_decode($hasil);
 foreach ($dt->items as $dta)
 {
  $time = $dta->contentDetails->duration;
  $samtime = sam_time($time);
  $views = $dta->statistics->viewCount;
  $likes = $dta->statistics->likeCount;
  $dislikes = $dta->statistics->dislikeCount;
 }
 echo '<div class="content_main">';
 echo '<div class="list_song">';
 echo '<a href="/view/videos/'.$id.'/'.$bersih.'.html" title="Download '.$name.' On '.$sitename.'">';
 echo '<table class="list_song_table">';
 echo '<tbody>';
 echo '<tr>';
 echo '<td class="list_song_table_left">';
 echo '<img src="http://ytimg.googleusercontent.com/vi/'.$id.'/default.jpg" class="thumbnail" alt="Thumbnail" />';
 echo '</td>';
 echo '<td class="list_song_table_right">';
 echo '<span class="green-link">';
 echo $name;
 echo '</span>';
 echo '<br />';
 echo 'Time: '.$samtime.'';
 echo '<br />';
 echo 'Upload: '.$samdate.'';
 echo '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';
 echo '</a>';
 echo '</div>';
 echo '</div>';
}
echo '<div class="pagination">';
if (strlen($prevpage)>1)
{
if (strlen($_GET['q'])>1)
{
 echo '<a href="/videos/'.$_GET['q'].'/page/'.$prevpage.'.html" class="page_item">&#171;Prev</a>';
}
}
if (strlen($nextpage)>1)
{
if (strlen($_GET['q'])>1)
{
 echo '<a href="/videos/'.$_GET['q'].'/page/'.$nextpage.'.html" class="page_item">Next&#187;</a>';
}
}
}
else
{
echo 'please contact adip.perdana@gmail.com';
}
echo '</div>';
echo '</div>';
include 'footer.php';
?>