<?php
include 'mfunc.php';
$default_artist = 'FLmedia';
$default_album = 'FLmedia';
$default_year = date("Y");
$id = $_GET['id'];

// START SONG DETAIL

$grab = json_decode(ngegrab('http://api.soundcloud.com/tracks/'.$id.'.json?client_id=30dbd25f772534b4dd327e929644d0d4'));

$createdat = $grab->created_at;
$createdat = str_replace('+0000', '', $createdat);
$createdat = strtolower($createdat);
$lastmodified = $grab->last_modified;
$lastmodified = str_replace('+0000', '', $lastmodified);
$lastmodified = strtolower($lastmodified);
$duration = format_time($grab->duration/1000);
$useride = $grab->user_id;
$sourcealamat = $grab->permalink_url;
if(!empty($grab->genre))
{
 $genre = $grab->genre;
}
else
{
 $genre = 'FLmedia';
}
if(!empty($grab->artwork_url))
{
 $thumb = $grab->artwork_url;
}
else
{
 $thumb = 'http://'.$host.'/files/thumbnail.jpg';
}
if(!empty($grab->label_name))
{
 $label = $grab->label_name;
}
else
{
 $label = '-';
}
if(!empty($grab->release_year))
{
 $release = $grab->release_year;
}
else
{
 $release = '-';
}
$playcount = $grab->playback_count;
$downcount = $grab->download_count;
$favocount = $grab->favoritings_count;
$comecount = $grab->comment_count;
$name = $grab->title;
$remove = "'";

if(!empty($grab->description))
{
 $desi = '<div class="description"><strong>Music Description</strong><p id="eow-description">'.$grab->description.'</p></div>';
}
else
{
 $desi = '';
}
$size = format_size(getfilesize(getlinkdl($id)));
$gambarnya = $thumb;

// END SONG DETAIL
// ************************
// START USER DETAIL

$datauser = json_decode(ngegrab('http://api.soundcloud.com/users/'.$useride.'.json?client_id=30dbd25f772534b4dd327e929644d0d4'));

$userpermalink = $datauser->permalink_url;
$usernama = $datauser->username;
$useravatar = $datauser->avatar_url;

// END USER DETAIL

if(!empty($name) && !empty($_GET['id']) && !empty($_GET['permalink']))
{
 $title = ''.$sitename.' - Download Music '.$name.'';
 include 'head.php';
 echo '<div class="content" id="content_main">';
 echo '<div class="content_view">';
 echo '<div class="title_music">';
 echo '<strong>'.$name.'</strong>';
 echo '<br />';
 echo '<span class="source_music">';
 echo 'Source: '.$sourcealamat.'';
 echo '</span>';
 echo '</div>';
 include 'ads2.php';
 include 'share.php';
 echo '<div class="content_detail">';
 echo '<div class="view_image">';
 echo '<img src="'.$thumb.'" alt="'.$name.'" class="view_thumbnail" />';
 echo '</div>';
// echo $desi;
 echo '<div class="file_detail">';
 echo '<strong>MUSIC DETAIL</strong>';
 echo '<p id="eow-detail">';
 echo 'Plays Count : '.$playcount.'';
 echo '<br />';
 echo 'Downloads Count : '.$downcount.'';
 echo '<br />';
 echo 'Favorits Count : '.$favocount.'';
 echo '<br />';
 echo 'Comments Count : '.$comecount.'';
 echo '<br />';
 echo 'Duration : '.$duration.'';
 echo '<br />';
 echo 'Created at : '.$createdat.'';
 echo '<br />';
 echo 'Last Modified : '.$lastmodified.'';
 echo '<br />';
 echo 'Uploaded by : <a href="'.$userpermalink.'" target="_blank" title="'.$usernama.'">'.$usernama.'</a>';
 echo '</p>';
 echo '</div>';
 echo '</div>';
 echo '<div class="download_files">';
 echo '<strong>DOWNLOAD MUSIC</strong>';
 include 'ads2.php';
 echo '<div class="view-download-button-link">';
// include 'adz.php';
 echo '<a href="/dhfmedia/'.$id.'.mp3" class="mime-download" title="Download '.$name.' On '.$sitename.'">';
 echo '<div class="button-link">';
 echo 'Download '.$name.' ('.$size.')';
 echo '</div>';
 echo '</a>';
 echo '</div>';
 include 'ads1.php';
 echo '</div>';
 include 'autopost.php';
 include 'ads2.php';
 echo '</div>';
 echo '</div>';

// RELATED MUSIC

include 'mrelated.php';
}
else
{
$title = 'Not Found';
include 'head.php';
echo 'Please Contact nahar.id22@gmail.com';
}
include 'footer.php';
?>