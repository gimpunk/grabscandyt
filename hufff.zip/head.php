<?php
if(!empty($gambarnya))
{
 $gambar = $gambarnya;
}
else
{
 $gambar = 'http://'.$host.'/files/anu.png';
}

if(!empty($name))
{
 $ogdesc = ''.$sitename.' - Download Music and Video '.$name.' On '.$sitename.' With Free. This Files Source From SoundCloud and YouTube';
}
else
{
 $ogdesc = ''.$sitename.' - Here You Can Download Music and Videos With Free. All Files Source From SoundCloud and YouTube';
}
?>
<!DOCTYPE HTML PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" />
<head>
  <title>
    <?php echo $title; ?>
  </title>
  <meta forua="true" http-equiv="Cache-Control" content="max-age=0" />
  <meta http-equiv="content-type" content="application/xhtml xml; charset=utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta name="description" content="<?php echo $ogdesc; ?>" />
  <meta name="keywords" content="<?php echo $sitename; ?>, Download Music and Videos With Free, Download Music, Download Videos, Download Music Free, Download Videos Free, Download<?php echo ' '.$name.''; ?> Free" />
  <meta property="og:title" content="<?php echo $title; ?>" />
  <meta property="og:description" content="<?php echo $ogdesc; ?>" />
  <meta property="og:image" content="<?php echo $gambar; ?>" />
  <meta name="google-site-verification" content="<?php echo $googlev; ?>" />
  <meta name="alexaVerifyID" content="<?php echo $alexav; ?>" />
  <meta name="robots" content="All,Index,Follow" />
  <meta name="author" content="<?php echo $author; ?>" />
  <meta name="copyright" content="<?php echo $sitename; ?> All Right Reserved." />
  <meta name="distribution" content="global" />
  <meta name="robots" content="noodp" />
  <meta name="Rating" content="General" />
  <meta name="revisit" content="1 days" />
  <meta name="revisit-after" content="1 days" />
  <meta name="language" content="id" />
  <meta name="geo.country" content="id" />
  <meta name="geo.placename" content="Indonesia" />
  <meta name="msnbot" content="follow, all" />
  <meta name="alexabot" content="follow, all" />
  <meta name="slurp" content="follow, all" />
  <meta name="zyborg" content="follow, all" />
  <meta name="scooter" content="follow, all" />
  <meta name="spiders" content="all" />
  <meta name="webcrawlers" content="all" />
  <meta name="rating" content="general" />
  <meta name="mssmarttagspreventparsing" content="true" />
  <meta name="search engines" content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET, Googlebot" />
  <meta itemprop="contributor" content="<?php echo $sitename; ?>" />
  <link rel="icon" href="http://<?php echo $host; echo $favico; ?>" type="image/x-icon"/>
  <link rel="shortcut icon" href="http://<?php echo $host; echo $favico; ?>" type="image/x-icon"/>
  <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css"/>
  <link rel="stylesheet" href="http://<?php echo $host; ?>/files/style.css" type="text/css"/>
  <style>
    .ui-autocomplete{color:#000!important;width:19px;}.ui-widget-content{background:rgba(255,255,255,0.5);border:1px solid #3B170B;margin:2px;padding-right:26px;padding-left:10px;padding-top:8px;padding-bottom:8px;text-decoration:none;-webkit-border-top-left-radius:3px;-webkit-border-top-right-radius:3px;-webkit-border-bottom-left-radius:3px;-webkit-border-bottom-right-radius:3px;cursor:pointer;font-weight:bold;font-size:15px;list-style:none;}.ui-autocomplete ui-front ui-menu ui-widget ui-widget-content{margin:0;padding:0;list-style:none;border:0;}ui-autocomplete ui-front ui-menu ui-widget ui-widget-content li{padding:;border:0;list-style:none;}
  </style>
</head>
<body>
  <div id="fb-root">
  </div>
  <div class="kelapa" align="center">
    <a class="fl" href="/">
      <a href="http://<?php echo $host; ?>" class="site_name_title_a" title="<?php echo $sitename; ?>"><?php echo $sitename; ?>
        - Download Music and Videos With Free
      </a>
      </div>
    <div id="wasu">
      <div class="content-wrapper">
        <table class="navigation_table" cellpading="0" cellspacing="0">
          <table border="0" class="tableup">
            <tbody>
              <tr>
                <td class="notd">
                  <a href="http://<?php echo $host; ?>/music" title="Music" rel="nofollow">
                    <div class="navigation_a">
                      Music
                    </div>
                  </a>
                </td>
                <td class="notd">
                  <a href="http://<?php echo $host; ?>/videos" title="Videos" rel="nofollow">
                    <div style="height:100%;width:100%">
                Videos
                    </div>
                  </a>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="kotakcari">
            <form id="form" method="get" action="http://<?php echo $host; ?>/search.php">
              <input id="input_word" type="text" class="search_input" placeholder="Input Everything Here.. ." name="q" />
              <input type="submit" class="search_submit" value="Search" title="Search Videos">
              </div>
            <div class="anu" align="center">
              <input type="radio" name="type" checked="checked" value="music">
              Music
              <input type="radio" name="type" value="videos">
              Videos
              </form>
            <script src="//code.jquery.com/jquery-1.10.2.js">
            </script>
            <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js">
            </script>
            <script src="http://malsup.github.io/min/jquery.form.min.js">
            </script>
            <script src="/data/complate.js">
            </script>
            <br/>
          