<?php
include('../mfunc.php');
$id=$_GET['id'] ;
$grab=json_decode(ngegrab('http://api.soundcloud.com/tracks/'.$id.'.json?client_id=a533a1377a8991455cf7aae220408712'));
$dl=''.getlinkdl($id).'';
$name=$grab->title;
header("Content-Type:audio/mpeg");
header("Content-length:".getfilesize(getlinkdl($id)));
header('Content-Disposition:attachment; filename="'.$name.'.mp3"');
readfile("$dl");
header("Content -Transfer-Encoding:binary");
?>