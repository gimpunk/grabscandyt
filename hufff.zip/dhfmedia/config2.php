<?PHP

#$config['ThumbnailImageMode']=0; 
#$config['ThumbnailImageMode']=1;
$config['ThumbnailImageMode']=2;

#$config['VideoLinkMode']='direct';
#$config['VideoLinkMode']='proxy';
$config['VideoLinkMode']='both';

$config['feature']['browserExtensions']=true;
 
date_default_timezone_set("Asia/Tehran");
  
#$debug=true; // debug mode on
$debug=false; // debug mode off

include_once('curl2.php');
?>