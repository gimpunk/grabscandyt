<?php

///The File Not Created By Me, But Im Just a Coder Just Fixed The Errors ////
/// feel free to contact me fb.com/mrakhilc ////


include_once('config2.php');
ob_start();

function clean($string)
{
$string = str_replace(' ', '-', $string);
return preg_replace('/[^A-Za-z0-9\-]/', '', $string);
}

function formatBytes($bytes, $precision = 2)
{
$units = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'); 
$bytes = max($bytes, 0); 
$pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
$pow = min($pow, count($units) - 1); 
$bytes /= pow(1024, $pow);
return round($bytes, $precision) . '' . $units[$pow]; 
} 

function videotype($data)
{
$originals = array("video/mp4","video/webm","video/mp4","video/x-flv","video/3gpp");
$replacements = array("Mp4","Webm","Mp4","FLV","3GPP");
$data = str_ireplace($originals,$replacements,$data);
return $data;
}

function videoquality($data)
{
$originals = array("hd720","medium","small");
$replacements = array("720p","360p","LQ");
$data = str_ireplace($originals,$replacements,$data);
return $data;
}

function is_chrome()
{
$agent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match("/like\sGecko\)\sChrome\//", $agent) )
{	// if user agent is google chrome
if(!strstr($agent, 'Iron')) // but not Iron
return true;
}
return false;
}

if(isset($_REQUEST['videoid']))
{
$my_id = $_REQUEST['videoid'];
if(strlen($my_id)>11)
{
$url = parse_url($my_id);
$my_id = NULL;
if(is_array($url) && count($url)>0 && isset($url['query']) && !empty($url['query']))
{
$parts = explode('&',$url['query']);
if(is_array($parts) && count($parts) > 0)
{
foreach($parts as $p)
{
$pattern = '/^v\=/';
if(preg_match($pattern, $p))
{
$my_id = preg_replace($pattern,'',$p);
break;
}
}
}
if( !$my_id )
{
echo '<p>Video is not passed</p>';
exit;
}
}
else
{
echo '<p>please check your url</p>';
exit;
}
}
}
else
{
echo '<p>id not passed</p>';
exit;
}

if(isset($_REQUEST['type']))
{
$my_type =  $_REQUEST['type'];
}
else
{
$my_type = 'redirect';
}

if ($my_type == 'Download')
{
?>
<?php
}

//$my_video_info = 'http://www.youtube.com/get_video_info?&video_id='. $my_id;
$my_video_info = 'http://www.youtube.com/get_video_info?&video_id='. $my_id.'&asv=3&el=detailpage&hl=en_US';
$my_video_info = curlGet($my_video_info);

$thumbnail_url = $title = $url_encoded_fmt_stream_map = $type = $url = '';

parse_str($my_video_info);

echo '';

$my_title = $title;
$cleanedtitle = clean($title);

if(isset($url_encoded_fmt_stream_map))
{
$my_formats_array = explode(',',$url_encoded_fmt_stream_map);
if($debug)
{
echo '<pre>';
print_r($my_formats_array);
echo '</pre>';
}
}
else
{
echo '<p>No encoded format stream found.</p>';
echo '<p>Here is what we got from YouTube:</p>';
echo $my_video_info;
}

if(count($my_formats_array) == 0)
{
echo '<p>No format stream map found - was the video id correct?</p>';
exit;
}

$avail_formats[] = '';
$i = 0;
$ipbits = $ip = $itag = $sig = $quality = '';
$expire = time(); 

foreach($my_formats_array as $format)
{
parse_str($format);
$avail_formats[$i]['itag'] = $itag;
$avail_formats[$i]['quality'] = $quality;
$type = explode(';',$type);
$avail_formats[$i]['type'] = $type[0];
$avail_formats[$i]['url'] = urldecode($url) . '&signature=' . $sig;
parse_str(urldecode($url));
$avail_formats[$i]['expires'] = date("G:i:s T", $expire);
$avail_formats[$i]['ipbits'] = $ipbits;
$avail_formats[$i]['ip'] = $ip;
$i++;
}

if ($debug)
{
echo '<p>These links will expire at '. $avail_formats[0]['expires'] .'</p>';
echo '<p>The server was at IP address '. $avail_formats[0]['ip'] .' which is an '. $avail_formats[0]['ipbits'] .' bit IP address. ';
echo 'Note that when 8 bit IP addresses are used, the download links may fail.</p>';
}

if ($my_type == 'Download')
{
for ($i = 0; $i < count($avail_formats); $i++)
{
echo '<div class="view-download-button-link">';
$typev = (videotype($avail_formats[$i]['type']));
$typeq = (videoquality($avail_formats[$i]['quality']));
$esize = (formatBytes(get_size($avail_formats[$i]['url'])));
if ($esize == "0B")
{
echo 'Reload The Page';
echo '</div>';
break;
}
else
{
if($config['VideoLinkMode']=='direct'||$config['VideoLinkMode']=='both')   

echo $typev;
echo '<a href="'.$avail_formats[$i]['url'].'&title='.$cleanedtitle.'" class="mime-download">';
echo '<div class="button-link">';
echo 'Download';
echo '</div>';
echo '</a>';

//else

echo $typev;
echo $typeq;
echo '[ ';
echo $esize;
echo ' ]';
echo '</div>';
}
}	
if(($config['feature']['browserExtensions']==true)&&(is_chrome())) 
?>
</body>
</html>

<?php
}
else
{
$format =  $_REQUEST['format'];
$target_formats = '';
switch ($format)
{
case "best":
$target_formats = array('38', '37', '46', '22', '45', '35', '44', '34', '18', '43', '6', '5', '17', '13');
break;
case "free":
$target_formats = array('38', '46', '37', '45', '22', '44', '35', '43', '34', '18', '6', '5', '17', '13');
break;
case "ipad":
$target_formats = array('37','22','18','17');
break;
default:
if(is_numeric($format))
{
$target_formats[] = $format;
}
else
{
$target_formats = array('38', '37', '46', '22', '45', '35', '44', '34', '18', '43', '6', '5', '17', '13');
}
break;
}

$best_format = '';
for($i=0; $i < count($target_formats); $i++)
{
for($j=0; $j < count ($avail_formats); $j++)
{
if($target_formats[$i] == $avail_formats[$j]['itag'])
{
			//echo '<p>Target format found, it is '. $avail_formats[$j]['itag'] .'</p>';
$best_format = $j;
break 2;
}
}
}

//echo '<p>Out of loop, best_format is '. $best_format .'</p>';
if((isset($best_format)) && (isset($avail_formats[$best_format]['url'])) && (isset($avail_formats[$best_format]['type'])))
{
$redirect_url = $avail_formats[$best_format]['url'].'&title='.$cleanedtitle;
$content_type = $avail_formats[$best_format]['type'];
}
if(isset($redirect_url)){
header("Location: $redirect_url"); 
}
}

?>