<?php

error_reporting(0);
$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];
$url = 'http://'.$host.''.$uri.'';
$sitename = 'FLmedia';
$author = 'Nanang'; 

$googlev = 'EryP1B0HoZZ1BKcc4x75c8TqqecBap2eO78mwTEXkno';

$alexav = 'F6-7rKCsb3ODZ005NLfp1kfgEl8';

$fbuser = 'wahyuthenightbat.ugakthefinestsin';


$twitter = '-';


$favico = '/files/favicon.ico';

$mail = 'wahyu@windowslive.com';

$info = 'Thank You, For Your Contact Me !<br />If You Found a Bug, Please Contact Me !';

$bid = array('HLkPxQTPxpw','bI5pwtWK37U','myZBN_poo_4','PRkpKeRFmrQ');
?>