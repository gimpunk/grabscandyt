<?php
include 'mfunc.php';
/*******************************************/
$kui = $_GET['q'];
$gen = $_GET['genre'];
$pag = $_GET['page'];
/*******************************************/
$div = "|#|";
$dat = 'lastsearch.txt';

$fp = fopen($dat, 'r');
$count = fgets($fp);
fclose($fp);
$data = explode($div, $count);
if(in_array($kui, $data))
{
 $tulis = implode($div, $data);
}
else
{
 $data = explode($div, $count);
$tulis = $data[1].''.$div.''.$data[2].''.$div.''.$data[3].''.$div.''.$data[4].''.$div.''.$data[5].''.$div.''.$data[6].''.$div.''.$data[7].''.$div.''.$data[8].''.$div.''.$data[9].''.$div.''.$data[10].''.$div.''.$data[11].''.$div.''.$data[12].''.$div.''.$data[13].''.$div.''.$data[14].''.$div.''.$data[15].''.$div.''.$data[16].''.$div.''.$data[17].''.$div.''.$data[18].''.$div.''.$data[19].''.$div.''.$data[20].''.$div;
 $tulis .= $kui;
}

if(!empty($_GET['q']))
{
$masuk = fopen($dat, 'w');
fwrite($masuk,$tulis);
fclose($masuk);
}


if(!empty($gen))
{
 $title = ''.$sitename.' - Download Music Genre '.$gen.'';
}
elseif(!empty($kui))
{
 $title = ''.$sitename.' - Download Music '.$kui.'';
}
else
{
 $title = ''.$sitename.' - Download Billions Music With Free';
}
/********************************************/
include 'head.php';
/********************************************/
if(!empty($gen))
{
 $genrer = str_replace(' ',',',strtolower($gen));
 $genrer = str_replace('_',',',$genrer);
 $genrer = str_replace('-',',',$genrer);
 $genre = $gen;
}
else
{
 $q = queryencode($kui);
 $artist = array('Tiffany Alvord');
 $no = rand(0,count($artist));
 $keyword = $artist[$no];
 $q = $q ? $q : $keyword;
}
/******************************************/
if(!empty($_GET['page']))
{
 $page = ($pag-1)*10;
}
else
{
 $pag = '1';
 $page = '0';
}
/***************************************/
if(!empty($gen))
{
 $json = json_decode(ngegrab('http://api.soundcloud.com/tracks.json?genres='.$genre.'&limit=10&offset='.$page.'&client_id=eb40dfdd499cf5721d47f21424fe28e4'));
}
else
{
 $json=json_decode(ngegrab('http://api.soundcloud.com/tracks.json?q='.str_replace(' ','-',$q).'&limit=10&offset='.$page.'&client_id=eb40dfdd499cf5721d47f21424fe28e4'));
}

echo '<div class="ngiri">';
echo '<h1 class="r"> MUSIC RESULT </h1>';

if(!empty($json[0]->title))
{
foreach($json as $list)
{
 $id = $list->id;
 $permalink = $list->permalink;
 $name = strip_tags($list->title);
 $size = format_size(getfilesize(getlinkdl($id)));
 $duration = format_time($list->duration/1000);
 if($song = $list->artwork_url)
 {
  $thumb = $song;
 }
 else
 {
  $thumb = 'http://'.$host.'/files/thumbnail.jpg';
 }
 echo '<table class="otable" width="100%">';
 echo '<tr>';
 echo '<td class="vithumb" width="100px">';
 echo '<a href="/view/music/'.$id.'/'.$permalink.'.html" title="'.$name.'" rel="dofollow">';
 echo '<img src="'.$thumb.'" alt="'.$name.'" class="thumbnail" />';
 echo '</a>';
 echo '</td">';
 echo '<td class="videsc">';
 echo '<a href="/view/music/'.$id.'/'.$permalink.'.html" title="'.$name.'" rel="dofollow">';
 echo $name;
 echo '</a>';
 echo '<br />';
 echo '<span>';
 echo 'Time: '.$duration.'';
 echo 'Size: '.$size.'';
 echo '</span>';
 echo '</td>';
 echo '</tr>';
 echo '</table>';
}
echo '<div class="vagination">';
if(!empty($_GET['genre']))
{
 if($pag > 1)
 {
  echo '<a href="/music/tags/'.$genre.'/'.($pag-1).'.html" class="page_item">&#171;Prev</a>';
 }
 if(!empty($json[9]))
 {
  echo '<a href="/music/tags/'.$genre.'/'.($pag+1).'.html" class="page_item">Next&#187;</a>';
 }
}
else
{
 if($pag > 1)
 {
  echo '<a href="/music/'.$q.'/page/'.($pag-1).'.html" class="page_item">&#171;Prev</a>';
 }
 if(!empty($json[9]))
 {
  echo '<a href="/music/'.$q.'/page/'.($pag+1).'.html" class="page_item">Next&#187;</a>';
 }
}
echo '</div>';
}
else
{
 echo 'please contact wahyu@windowslive.com';
}
 echo '</div>';
include 'footer.php';
?>