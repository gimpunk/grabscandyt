<?php

if(!empty($_GET['page']))
{
 $pag = $_GET['page'];
}
else
{
 $pag = '1';
}

include 'info.php';
$title = ''.$sitename.' - Top Track';
include 'head.php';

echo '<div class="content" id="content_main">';
echo '<div class="content_title">';
echo '<strong>TOP TRACK</strong>';
echo '</div>';

$json = file_get_contents('http://ws.audioscrobbler.com/2.0/?method=chart.gettoptracks&api_key=7df2ba528dcd0d495e3db6284ee6e1a3&format=json&limit=10&page='.$pag.'');

$json = json_decode($json, true);

foreach($json['tracks']['track'] as $track)
{
 $name = $track['name'];
 $artist = $track['artist']['name'];
 $title = ''.$artist.' - '.$name.'';
 $image = $track['image'][3]['#text'];
 $play = $track['playcount'];
 $listen = $track['listeners'];
 echo '<div class="content_main">';
 echo '<div class="list_song">';
 echo '<a href="/music/'.$title.'.html" title="Download Music '.$title.' On '.$sitename.'" rel="dofollow">';
 echo '<table class="list_song_table">';
 echo '<tbody>';
 echo '<tr>';
 echo '<td class="list_song_table_left">';
 echo '<img src="'.$image.'" alt="'.$title.'" class="thumbnail" />';
 echo '</td>';
 echo '<td class="list_song_table_right">';
 echo '<span class="green-link">';
 echo $title;
 echo '</span>';
 echo '<br />';
 echo ''.$play.' Plays';
 echo '<br />';
 echo ''.$listen.' Listeners';
 echo '</td>';
 echo '</tr>';
 echo '</tbody>';
 echo '</table>';
 echo '</a>';
 echo '</div>';
 echo '</div>';
}

echo '</div>';

include 'footer.php';

?>